/** @file
  IPMI 2.0 definitions from the IPMI Specification Version 2.0, Revision 1.1.

  This file contains all NetFn Chassis commands, including:
    Chassis Commands (Chapter 28)

  See IPMI specification, Appendix G, Command Assignments
  and Appendix H, Sub-function Assignments.

  Copyright (c) 1999 - 2015, Intel Corporation. All rights reserved.<BR>
  This program and the accompanying materials
  are licensed and made available under the terms and conditions of the BSD License
  which accompanies this distribution.  The full text of the license may be found at
  http://opensource.org/licenses/bsd-license.php

  THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
  WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
**/

#ifndef _IPMI_NET_FN_CHASSIS_H_
#define _IPMI_NET_FN_CHASSIS_H_

#pragma pack (1)
//
// Net function definition for Chassis command
//
#define IPMI_NETFN_CHASSIS  0x00

//
//  Below is Definitions for Chassis commands (Chapter 28)
//

//
//  Definitions for Get Chassis Capabilities command
//
#define IPMI_CHASSIS_GET_CAPABILITIES  0x00

//
//  Constants and Structure definitions for "Get Chassis Capabilities" command to follow here
//

//
//  Definitions for Get Chassis Status command
//
#define IPMI_CHASSIS_GET_STATUS  0x01

//
//  Constants and Structure definitions for "Get Chassis Status" command to follow here
//

//
//  Definitions for Chassis Control command
//
#define IPMI_CHASSIS_CONTROL 0x02

//
//  Constants and Structure definitions for "Chassis Control" command to follow here
//

//
//  Definitions for Chassis Reset command
//
#define IPMI_CHASSIS_RESET 0x03

//
//  Constants and Structure definitions for "Chassis Reset" command to follow here
//

//
//  Definitions for Chassis Identify command
//
#define IPMI_CHASSIS_IDENTIFY  0x04

//
//  Constants and Structure definitions for "Chassis Identify" command to follow here
//

//
//  Definitions for Set Chassis Capabilities command
//
#define IPMI_CHASSIS_SET_CAPABILITIES  0x05

//
//  Constants and Structure definitions for "Set Chassis Capabilities" command to follow here
//

//
//  Definitions for Set Power Restore Policy command
//
#define IPMI_CHASSIS_SET_POWER_RESTORE_POLICY  0x06

//
//  Constants and Structure definitions for "Set Power Restore Policy" command to follow here
//

//
//  Definitions for Get System Restart Cause command
//
#define IPMI_CHASSIS_GET_SYSTEM_RESTART_CAUSE  0x07

//
//  Constants and Structure definitions for "Get System Restart Cause" command to follow here
//
typedef enum {
  Unknown,
  ChassisControlCommand,
  ResetViaPushButton,
  PowerupViaPowerButton,
  WatchdogExpiration,
  Oem,
  AutoPowerOnAlwaysRestore,
  AutoPowerOnRestorePrevious,
  ResetViaPef,
  PowerCycleViaPef,
  SoftReset,
  PowerUpViaRtc
} IPMI_SYSTEM_RESTART_CAUSE;

typedef struct {
  UINT8  CompletionCode;
  UINT8  Cause:4;
  UINT8  Reserved:4;
  UINT8  ChannelNumber;
} IPMI_GET_SYSTEM_RESTART_CAUSE_RESPONSE;

//
//  Definitions for Set System BOOT options command
//
#define IPMI_CHASSIS_SET_SYSTEM_BOOT_OPTIONS 0x08

//
//  Constants and Structure definitions for "Set System boot options" command to follow here
//
/**
    Get Boot Options parameter types.
*/
typedef enum {
  SetInProgress,              ///< Set In Progress.
  ServicePartitionSelector,   ///< Service Partition Selector.
  ServicePartitionScan,       ///< Service Partition Scan.
  BmcBootFlagValidBit,        ///< Bmc Boot Flag Valid Bit.
  BootInfoAck,                ///< Boot Info Ack.
  BootFlags,                  ///< Boot Flags.
  BootInitiatorInfo,          ///< Boot Initiator Info.
  BootInitiatorMailbox        ///< Boot Initiator Mailbox.
} IPMI_BOOT_OPTION_PARAMETER_TYPE;

/**
    Parameter 5 data 3 Force Boot Device Selection.
*/
typedef enum {
  NoOverride,                     ///< No Override.
  ForcePxe,                       ///< Force Pxe.
  ForceBootHardDrive,             ///< Force Boot Hard Drive.
  ForceBootHardDriveSafeMode,     ///< Force Boot Hard Drive Safe Mode.
  ForceBootDiagnosticPartition,   ///< Force Boot DiagnosticPartition.
  ForceBootCdDvd,                 ///< Force Boot Cd/Dvd.
  ForceBootBiosSetup,             ///< Force Boot Bios Setup.
  ForceBootRemoteFloppy,          ///< Force Boot Remote Floppy.
  ForceBootRemoteCdDvd,           ///< Force Boot Remote Cd/Dvd.
  ForceBootPrimaryRemoteMedia,    ///< Force Boot Primary Remote Media.
  ForceBootRemoteHardDrive = 0xB, ///< Force Boot Remote Hard Drive.
  ForceBootFloppy = 0xF           ///< Force Boot Floppy.
} IPMI_BOOT_DEVICE;

/**
    Boot Options Parameter# 5 - Boot Flags.
    It is same as IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_5.
    Since Data 5 and other members are not defined, using below structure.
*/
typedef struct {
  /// Reserved.
  // Data 1
  UINT8    Reserved:5;
  UINT8    BiosBootType:1;            ///< Bios boot type.
  UINT8    Persistent:1;              ///< Persistent bit.
  UINT8    BootFlagValid:1;           ///< Boot flag valid bit.
  // Data 2
  UINT8    LockoutResetButtons:1;     ///< Lock out reset buttons bit.
  UINT8    ScreenBlank:1;             ///< Screen blank bit.
  UINT8    BootDeviceSelector:4;      ///< Boot device selector.
  UINT8    LockKeyboard:1;            ///< Lock keyboard bit.
  UINT8    CmosClear:1;               ///< Cmos clear bit.
  // Data 3
  UINT8    ConsoleRedirection:2;      ///< Console redirection.
  UINT8    LockOutSleepButton:1;      ///< Lock out sleep button bit.
  UINT8    UserPasswordBypass:1;      ///< User password bypass bit.
  UINT8    ForceProgressEventTrap:1;  ///< Force progress trap bit.
  UINT8    FirmwareVerbosity:2;       ///< Verbosity.
  UINT8    LockoutPowerButton:1;      ///< Lock out power button bit.
  // Data 4
  UINT8    BiosMuxCtrlOverride:3;     ///< Bios Mux control override.
  UINT8    BiosSharedModeOverride:1;  ///< Bios shared mode override.
  UINT8    Reserved1:4;               ///< Reserved.
  // Data 5
  UINT8    DeviceInstanceSelector:5;  ///< Device instance selector.
  UINT8    Reserved2:3;               ///< Reserved.
} IPMI_BOOT_OPTIONS_BOOT_FLAGS;

typedef struct {
  UINT8    ParameterSelector:7;
  UINT8    MarkParameterInvalid:1;
  UINT8    ParameterData[1];
} IPMI_SET_BOOT_OPTIONS_REQUEST;

/**
    Set boot flags param 5 request structure.
*/
typedef struct {
  /// Request data.
  IPMI_SET_BOOT_OPTIONS_REQUEST    Request;
  IPMI_BOOT_OPTIONS_BOOT_FLAGS     Param5;     ///< Boot flags.
} IPMI_SET_BOOT_FLAG_REQUEST;

//
//  Definitions for Get System Boot options command
//
#define IPMI_CHASSIS_GET_SYSTEM_BOOT_OPTIONS 0x09

//
//  Constants and Structure definitions for "Get System boot options" command to follow here
//

// BIOS Mux Control Override
#define REQUEST_TO_SYSTEM       0x00
#define FORCE_TO_BMC            0x01
#define FORCE_TO_SYSTEM         0x02

typedef struct {
  UINT8    ParameterSelector:7;
  UINT8    Reserved:1;
  UINT8    SetSelector;
  UINT8    BlockSelector;
} IPMI_GET_BOOT_OPTIONS_REQUEST;

typedef struct {
  UINT8 Parameter;
  UINT8 Valid;
  UINT8 Data1;
  UINT8 Data2;
  UINT8 Data3;
  UINT8 Data4;
  UINT8 Data5;
} IPMI_GET_THE_SYSTEM_BOOT_OPTIONS;

typedef struct {
  UINT8   ParameterVersion;
  UINT8   ParameterValid;
  UINT8   ChannelNumber;
  UINT32  SessionId;
  UINT32  TimeStamp;
  UINT8   Reserved[3];
} IPMI_BOOT_INITIATOR;

//
// Response Parameters for IPMI Get Boot Options
//
/**
    Get set in progress response structure.
*/
typedef struct {
  UINT8   SetInProgress: 2;
  UINT8   Reserved: 6;
} IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_0;

typedef struct {
  /// Response data.
  IPMI_GET_BOOT_OPTIONS_RESPONSE          Response;
  /// Set in progress response.
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_0  Param0;
} IPMI_GET_SET_IN_PROGRESS_RESPONSE;

typedef struct {
  UINT8   ServicePartitionSelector;
} IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_1;

typedef struct {
  UINT8   ServicePartitionDiscovered:1;
  UINT8   ServicePartitionScanRequest:1;
  UINT8   Reserved: 5;
} IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_2;

typedef struct {
  UINT8   BmcBootFlagValid: 5;
  UINT8   Reserved: 3;
} IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_3;

typedef struct {
  UINT8   WriteMask;
  UINT8   BootInitiatorAcknowledgeData;
} IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_4;

/**
    Set boot info acknowledge request structure.
*/
typedef struct {
  /// Request data.
  IPMI_SET_BOOT_OPTIONS_REQUEST           Request;
  /// Boot info acknowledge data.
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_4  Param4;
} IPMI_SET_BOOT_INFO_ACK_REQUEST;

/**
    Set boot info acknowledge response structure.
*/
typedef struct {
  /// Response data.
  IPMI_GET_BOOT_OPTIONS_RESPONSE          Response;
  /// Boot info acknowledge data.
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_4  Param4;
} IPMI_BOOT_INFO_ACKNOWLEDGE_RESPONSE;


#define BOOT_OPTION_HANDLED_BY_BIOS 0x01

typedef struct {
  UINT8   ChannelNumber:4;
  UINT8   Reserved:4;
  UINT8   SessionId[4];
  UINT8   BootInfoTimeStamp[4];
} IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_6;

typedef struct {
  UINT8   SetSelector;
  UINT8   BlockData[16];
} IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_7;

typedef union {
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_0   Param0;
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_1   Param1;
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_2   Param2;
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_3   Param3;
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_4   Param4;
  IPMI_BOOT_OPTIONS_BOOT_FLAGS             Param5;
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_6   Param6;
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_7   Param7;
} IPMI_BOOT_OPTIONS_PARAMETERS;

typedef struct {
  UINT8    CompletionCode;
  UINT8    ParameterVersion:4;
  UINT8    Reserved:4;
  UINT8    ParameterSelector:7;
  UINT8    ParameterValid:1;
  UINT8    ParameterData[1];
} IPMI_GET_BOOT_OPTIONS_RESPONSE;

/**
    Get set in progress response structure.
*/
typedef struct {
  /// Response data.
  IPMI_GET_BOOT_OPTIONS_RESPONSE          Response;
  /// Set in progress response.
  IPMI_BOOT_OPTIONS_RESPONSE_PARAMETER_0  Param0;
} IPMI_GET_SET_IN_PROGRESS_RESPONSE;

/**
    Get boot flag response structure.
*/
typedef struct {
  /// Response data.
  IPMI_GET_BOOT_OPTIONS_RESPONSE  Response;
  IPMI_BOOT_OPTIONS_BOOT_FLAGS     Param5;     ///< Boot flags.
} IPMI_GET_BOOT_FLAG_RESPONSE;

//
//  Definitions for Set front panel button enables command
//
#define IPMI_CHASSIS_SET_FRONT_PANEL_BUTTON_ENABLES 0x0A

typedef struct {
  UINT8    DisablePoweroffButton:1;
  UINT8    DisableResetButton:1;
  UINT8    DisableDiagnosticInterruptButton:1;
  UINT8    DisableStandbyButton:1;
  UINT8    Reserved:4;
} IPMI_CHASSIS_SET_FRONT_PANEL_BUTTON_ENABLES_REQUEST;

//
//  Constants and Structure definitions for "Set front panel button enables" command to follow here
//

//
//  Definitions for Set Power Cycle Interval command
//
#define IPMI_CHASSIS_SET_POWER_CYCLE_INTERVALS 0x0B

//
//  Constants and Structure definitions for "Set Power Cycle Interval" command to follow here
//

//
//  Definitions for Get POH Counter command
//
#define IPMI_CHASSIS_GET_POH_COUNTER 0x0F

//
//  Constants and Structure definitions for "Get POH Counter" command to follow here
//
#pragma pack()
#endif
