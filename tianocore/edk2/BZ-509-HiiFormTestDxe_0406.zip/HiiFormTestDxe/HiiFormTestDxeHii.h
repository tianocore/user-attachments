/** @file

**/

#ifndef __HII_FORM_TEST_DXE_HII_H__
#define __HII_FORM_TEST_DXE_HII_H__

#define HII_FORM_TEST_FORMSET_GUID \
  {0x1265f7b3, 0x7e2d, 0x404f, {0xbf, 0x72, 0xf7, 0x43, 0xcc, 0x5f, 0x32, 0x21}}

#define FORM_TEST_MAIN_FORM_ID                  0x1
#define FORM_TEST_DYNAMIC_FORM_ID               0x100
#define FORM_TEST_DYNAMIC_FORM_LABEL_START      0x1000
#define FORM_TEST_DYNAMIC_FORM_LABEL_END        0x1001
#define FORM_TEST_DYNAMIC_FORM_CALLBACK         0x2000

#pragma pack(1)
typedef struct {
  UINT8     Oneof1;
  UINT8     Oneof2;
} FORM_TEST_VARIABLE;
#pragma pack()

#endif