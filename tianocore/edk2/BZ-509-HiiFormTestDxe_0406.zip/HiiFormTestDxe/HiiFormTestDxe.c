/*++ @file


**/

#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/UefiDriverEntryPoint.h>
#include <Library/BaseLib.h>
#include <Library/DebugLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/HiiLib.h>
#include <Library/DevicePathLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/PrintLib.h>
#include <Protocol/DriverBinding.h>
#include <Protocol/HiiConfigRouting.h>
#include <Protocol/HiiConfigAccess.h>
#include <Protocol/HiiDatabase.h>
#include <Protocol/DevicePath.h>
#include <Protocol/SimpleFileSystem.h>
#include <Guid/MdeModuleHii.h>
#include "HiiFormTestDxeHii.h"

extern UINT8    HiiFormTestDxeVfrBin[];
extern UINT8    HiiFormTestDxeStrings[];


typedef struct {
  EFI_HANDLE                        DriverHandle;
  EFI_HII_HANDLE                    HiiHandle;
  FORM_TEST_VARIABLE                FormTestVariable;
  EFI_HII_DATABASE_PROTOCOL         *HiiDatabase;
  EFI_HII_CONFIG_ROUTING_PROTOCOL   *HiiConfigRouting;
  EFI_HII_CONFIG_ACCESS_PROTOCOL    ConfigAccess;
} HII_FORM_TEST_PRIVATE_DATA;

typedef struct {
  VENDOR_DEVICE_PATH             VendorDevicePath;
  EFI_DEVICE_PATH_PROTOCOL       End;
} HII_VENDOR_DEVICE_PATH;

UINT8                       mVfrInterface = 0;
EFI_GUID                    mVfrInterfaceProtocolGuid = \
  {0xf0f24414, 0xee04, 0x40cd, {0x8c, 0xe9, 0x2f, 0x9b, 0x54, 0x1f, 0x6d, 0xad}};

EFI_GUID                    mHiiFormTestFormsetGuid = HII_FORM_TEST_FORMSET_GUID;
HII_FORM_TEST_PRIVATE_DATA  mPrivate;
HII_VENDOR_DEVICE_PATH      mHiiVendorDevicePath = {
  {
    {
      HARDWARE_DEVICE_PATH,
      HW_VENDOR_DP,
      {
        (UINT8) (sizeof (VENDOR_DEVICE_PATH)),
        (UINT8) ((sizeof (VENDOR_DEVICE_PATH)) >> 8)
      }
    },
    HII_FORM_TEST_FORMSET_GUID
  },
  {
    END_DEVICE_PATH_TYPE,
    END_ENTIRE_DEVICE_PATH_SUBTYPE,
    {
      (UINT8) (END_DEVICE_PATH_LENGTH),
      (UINT8) ((END_DEVICE_PATH_LENGTH) >> 8)
    }
  }
};

EFI_STATUS
EFIAPI
VfrBindingSupported (
  IN EFI_DRIVER_BINDING_PROTOCOL  *This,
  IN EFI_HANDLE                   ControllerHandle,
  IN EFI_DEVICE_PATH_PROTOCOL     *RemainingDevicePath OPTIONAL
  );

EFI_STATUS
EFIAPI
VfrBindingStart (
  IN EFI_DRIVER_BINDING_PROTOCOL  *This,
  IN EFI_HANDLE                   ControllerHandle,
  IN EFI_DEVICE_PATH_PROTOCOL     *RemainingDevicePath OPTIONAL
  );

EFI_STATUS
EFIAPI
VfrBindingStop (
  IN EFI_DRIVER_BINDING_PROTOCOL  *This,
  IN EFI_HANDLE                   ControllerHandle,
  IN UINTN                        NumberOfChildren,
  IN EFI_HANDLE                   *ChildHandleBuffer OPTIONAL
  );



EFI_STATUS
EFIAPI
ExtractConfig (
  IN  CONST EFI_HII_CONFIG_ACCESS_PROTOCOL   *This,
  IN  CONST EFI_STRING                       Request,
  OUT EFI_STRING                             *Progress,
  OUT EFI_STRING                             *Results
  )
{
  EFI_STATUS                       Status;
  UINTN                            BufferSize;
  EFI_STRING                       ConfigRequest;
  EFI_STRING                       ConfigRequestHdr;
  UINTN                            Size;
  CHAR16                           *StrPointer;
  BOOLEAN                          AllocatedRequest;

  ConfigRequestHdr = NULL;
  ConfigRequest = NULL;

  if (Progress == NULL || Results == NULL) {
    return EFI_INVALID_PARAMETER;
  }

  BufferSize = sizeof (mPrivate.FormTestVariable);
  if (Request == NULL || Request[0] == L'\0') {
    //
    // Request is set to NULL, construct full request string.
    //

    //
    // Allocate and fill a buffer large enough to hold the <ConfigHdr> template
    // followed by "&OFFSET=0&WIDTH=WWWWWWWWWWWWWWWW" followed by a Null-terminator
    //
    ConfigRequestHdr = HiiConstructConfigHdr (&mHiiFormTestFormsetGuid, L"FormTestVariable", mPrivate.DriverHandle);
    Size = (StrLen (ConfigRequestHdr) + 32 + 1) * sizeof (CHAR16);
    ConfigRequest = AllocateZeroPool (Size);
    ASSERT (ConfigRequest != NULL);
    AllocatedRequest = TRUE;
    UnicodeSPrint (ConfigRequest, Size, L"%s&OFFSET=0&WIDTH=%016LX", ConfigRequestHdr, (UINT64)BufferSize);
    FreePool (ConfigRequestHdr);
    ConfigRequestHdr = NULL;
  } else {
    //
    // Check routing data in <ConfigHdr>.
    // Note: if only one Storage is used, then this checking could be skipped.
    //
    if (!HiiIsConfigHdrMatch (Request, &mHiiFormTestFormsetGuid, NULL)) {
      return EFI_NOT_FOUND;
    }

    //
    // Set Request to the unified request string.
    //
    ConfigRequest = Request;
    //
    // Check whether Request includes Request Element.
    //
    if (StrStr (Request, L"OFFSET") == NULL) {
      DEBUG ((DEBUG_ERROR, "%a %d\n", __FUNCTION__, __LINE__));
      //
      // Check Request Element does exist in Reques String
      //
      StrPointer = StrStr (Request, L"PATH");
      if (StrPointer == NULL) {
        return EFI_INVALID_PARAMETER;
      }
      if (StrStr (StrPointer, L"&") == NULL) {
        Size = (StrLen (Request) + 32 + 1) * sizeof (CHAR16);
        ConfigRequest    = AllocateZeroPool (Size);
        ASSERT (ConfigRequest != NULL);
        AllocatedRequest = TRUE;
        UnicodeSPrint (ConfigRequest, Size, L"%s&OFFSET=0&WIDTH=%016LX", Request, (UINT64)BufferSize);
      }
    }
  }

  if (StrStr (ConfigRequest, L"OFFSET") == NULL) {
    DEBUG ((DEBUG_ERROR, "%a %d\n", __FUNCTION__, __LINE__));
    Status = EFI_UNSUPPORTED;
  } else {
    //
    // Convert buffer data to <ConfigResp> by helper function BlockToConfig()
    //
    Status = mPrivate.HiiConfigRouting->BlockToConfig (
                                          mPrivate.HiiConfigRouting,
                                          ConfigRequest,
                                          (UINT8 *) &mPrivate.FormTestVariable,
                                          BufferSize,
                                          Results,
                                          Progress
                                          );
  }

  //
  // Free the allocated config request string.
  //
  if (AllocatedRequest) {
    FreePool (ConfigRequest);
  }

  if (ConfigRequestHdr != NULL) {
    FreePool (ConfigRequestHdr);
  }
  
  //
  // Set Progress string to the original request string.
  //
  if (Request == NULL) {
    *Progress = NULL;
  } else if (StrStr (Request, L"OFFSET") == NULL) {
    *Progress = Request + StrLen (Request);
  }

  return Status;
}

EFI_STATUS
EFIAPI
RouteConfig (
  IN  CONST EFI_HII_CONFIG_ACCESS_PROTOCOL   *This,
  IN  CONST EFI_STRING                       Configuration,
  OUT EFI_STRING                             *Progress
  )
{
  EFI_STATUS      Status;
  UINTN           BufferSize;

  if (Configuration == NULL || Progress == NULL) {
    return EFI_INVALID_PARAMETER;
  }

  *Progress = Configuration;

  //
  // Check routing data in <ConfigHdr>.
  // Note: if only one Storage is used, then this checking could be skipped.
  //
  if (!HiiIsConfigHdrMatch (Configuration, &mHiiFormTestFormsetGuid, NULL)) {
    return EFI_NOT_FOUND;
  }

  //
  // Convert <ConfigResp> to buffer data by helper function ConfigToBlock()
  //
  BufferSize = sizeof (mPrivate.FormTestVariable);
  Status = mPrivate.HiiConfigRouting->ConfigToBlock (
                               mPrivate.HiiConfigRouting,
                               Configuration,
                               (UINT8 *) &mPrivate.FormTestVariable,
                               &BufferSize,
                               Progress
                               );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  return Status;
}

EFI_STATUS
EFIAPI
DriverCallback (
  IN  CONST EFI_HII_CONFIG_ACCESS_PROTOCOL   *This,
  IN  EFI_BROWSER_ACTION                     Action,
  IN  EFI_QUESTION_ID                        QuestionId,
  IN  UINT8                                  Type,
  IN  EFI_IFR_TYPE_VALUE                     *Value,
  OUT EFI_BROWSER_ACTION_REQUEST             *ActionRequest
  )
{
  if (Action != EFI_BROWSER_ACTION_CHANGING) {
    return EFI_UNSUPPORTED;
  }

  if (QuestionId == FORM_TEST_DYNAMIC_FORM_CALLBACK) {
    VOID                            *StartOpCodeHandle;
    EFI_IFR_GUID_LABEL              *StartLabel;
    VOID                            *EndOpCodeHandle;
    EFI_IFR_GUID_LABEL              *EndLabel;

    DEBUG ((DEBUG_ERROR, "%a %d QuestionId:%x Action:%x\n", __FUNCTION__, __LINE__, QuestionId, Action));
    StartOpCodeHandle = HiiAllocateOpCodeHandle ();
    ASSERT (StartOpCodeHandle != NULL);

    EndOpCodeHandle = HiiAllocateOpCodeHandle ();
    ASSERT (EndOpCodeHandle != NULL);
    
    //
    // Create Hii Extend Label OpCode as the start opcode
    //
    StartLabel = (EFI_IFR_GUID_LABEL *) HiiCreateGuidOpCode (StartOpCodeHandle, &gEfiIfrTianoGuid, NULL, sizeof (EFI_IFR_GUID_LABEL));
    StartLabel->ExtendOpCode = EFI_IFR_EXTEND_OP_LABEL;
    StartLabel->Number       = FORM_TEST_DYNAMIC_FORM_LABEL_START;

    //
    // Create Hii Extend Label OpCode as the end opcode
    //
    EndLabel = (EFI_IFR_GUID_LABEL *) HiiCreateGuidOpCode (EndOpCodeHandle, &gEfiIfrTianoGuid, NULL, sizeof (EFI_IFR_GUID_LABEL));
    EndLabel->ExtendOpCode = EFI_IFR_EXTEND_OP_LABEL;
    EndLabel->Number       = FORM_TEST_DYNAMIC_FORM_LABEL_END;

    HiiCreateTextOpCode (
      StartOpCodeHandle,
      STRING_TOKEN (STR_DYNAMIC_FORM_ITEM1),
      STRING_TOKEN (STR_DYNAMIC_FORM_ITEM1_HELP),
      STRING_TOKEN (STR_FORM_TEST_EMPTY)
      );

    HiiUpdateForm (
      mPrivate.HiiHandle,
      &mHiiFormTestFormsetGuid,
      FORM_TEST_DYNAMIC_FORM_ID,
      StartOpCodeHandle,
      EndOpCodeHandle
      );

    HiiFreeOpCodeHandle (StartOpCodeHandle);
    HiiFreeOpCodeHandle (EndOpCodeHandle);
    return EFI_SUCCESS;
  }

  return EFI_UNSUPPORTED;
}

EFI_DRIVER_BINDING_PROTOCOL mVfrDriverBinding = {
  VfrBindingSupported,
  VfrBindingStart,
  VfrBindingStop,
  0xa,
  NULL,
  NULL
};

EFI_STATUS
EFIAPI
VfrBindingSupported (
  IN EFI_DRIVER_BINDING_PROTOCOL  *This,
  IN EFI_HANDLE                   ControllerHandle,
  IN EFI_DEVICE_PATH_PROTOCOL     *RemainingDevicePath OPTIONAL
  )
{
  EFI_STATUS      Status;

  Status = gBS->OpenProtocol (
                  ControllerHandle,
                  &gEfiSimpleFileSystemProtocolGuid,
                  NULL,
                  This->DriverBindingHandle,
                  ControllerHandle,
                  EFI_OPEN_PROTOCOL_TEST_PROTOCOL
                  );
  if (EFI_ERROR (Status)) return EFI_UNSUPPORTED;
  
  Status = gBS->OpenProtocol (
                  ControllerHandle,
                  &mVfrInterfaceProtocolGuid,
                  NULL,
                  This->DriverBindingHandle,
                  ControllerHandle,
                  EFI_OPEN_PROTOCOL_TEST_PROTOCOL
                  );
  if (!EFI_ERROR (Status)) {
    return EFI_ALREADY_STARTED;
  }

  return EFI_SUCCESS;
}


EFI_STATUS
EFIAPI
VfrBindingStart (
  IN EFI_DRIVER_BINDING_PROTOCOL  *This,
  IN EFI_HANDLE                   ControllerHandle,
  IN EFI_DEVICE_PATH_PROTOCOL     *RemainingDevicePath OPTIONAL
  )
{
  EFI_STATUS          Status;
  VOID                *Interface;

  Status = gBS->OpenProtocol (
                  ControllerHandle,
                  &gEfiSimpleFileSystemProtocolGuid,
                  (VOID *)&Interface,
                  This->DriverBindingHandle,
                  ControllerHandle,
                  EFI_OPEN_PROTOCOL_BY_DRIVER
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }

  gBS->SetMem (&mPrivate, sizeof (mPrivate), 0);

  mPrivate.ConfigAccess.ExtractConfig = ExtractConfig;
  mPrivate.ConfigAccess.RouteConfig = RouteConfig;
  mPrivate.ConfigAccess.Callback = DriverCallback;

  Status = gBS->LocateProtocol (&gEfiHiiDatabaseProtocolGuid, NULL, (VOID **) &mPrivate.HiiDatabase);
  if (EFI_ERROR (Status)) {
    return Status;
  }

  Status = gBS->LocateProtocol (&gEfiHiiConfigRoutingProtocolGuid, NULL, (VOID **) &mPrivate.HiiConfigRouting);
  if (EFI_ERROR (Status)) {
    return Status;
  }

  Status = gBS->InstallMultipleProtocolInterfaces (
                  &ControllerHandle,
                  &mVfrInterfaceProtocolGuid,
                  &mVfrInterface,
                  &gEfiHiiConfigAccessProtocolGuid,
                  &mPrivate.ConfigAccess,
                  NULL
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }
  
  mPrivate.DriverHandle = ControllerHandle;
  mPrivate.HiiHandle = HiiAddPackages (
                         &mHiiFormTestFormsetGuid,
                         mPrivate.DriverHandle,
                         HiiFormTestDxeStrings,
                         HiiFormTestDxeVfrBin,
                         NULL
                         );
  if (mPrivate.HiiHandle == NULL) {
    return EFI_OUT_OF_RESOURCES;
  }

  return Status;
}

EFI_STATUS
EFIAPI
VfrBindingStop (
  IN EFI_DRIVER_BINDING_PROTOCOL  *This,
  IN EFI_HANDLE                   ControllerHandle,
  IN UINTN                        NumberOfChildren,
  IN EFI_HANDLE                   *ChildHandleBuffer OPTIONAL
  )
{
  EFI_STATUS      Status;

  HiiRemovePackages (mPrivate.HiiHandle);
  Status = gBS->UninstallMultipleProtocolInterfaces (
                  ControllerHandle,
                  &mVfrInterfaceProtocolGuid,
                  &mVfrInterface,
                  &gEfiHiiConfigAccessProtocolGuid,
                  &mPrivate.ConfigAccess,
                  NULL
                  );
  if (EFI_ERROR (Status)) {
    return Status;
  }
  
  Status = gBS->CloseProtocol (
                  ControllerHandle,
                  &gEfiSimpleFileSystemProtocolGuid,
                  This->DriverBindingHandle,
                  ControllerHandle
                  );
  return Status;
}


EFI_STATUS
EFIAPI
HiiFormTestDxeEntry (
  IN EFI_HANDLE         ImageHandle,
  IN EFI_SYSTEM_TABLE   *SystemTable
  )
{
  EFI_STATUS            Status;

  //
  // Update the ImageHandle and DriverBindingHandle fields of the Driver Binding Protocol
  //
  mVfrDriverBinding.ImageHandle         = ImageHandle;
  mVfrDriverBinding.DriverBindingHandle = ImageHandle;

  //
  // This is demo binding driver that will install ConfigAcces/VfrInterface on filesytem handle.
  //
  // It just demonstrate some option rom will install its driver on specific pci device. Provide
  // HII page for configurating device. PCI device is not available with EmulatorPkg so use filesystem
  // protocol to substitute.
  //
  Status = gBS->InstallMultipleProtocolInterfaces (
                  &mVfrDriverBinding.DriverBindingHandle,
                  &gEfiDriverBindingProtocolGuid,
                  &mVfrDriverBinding,
                  NULL
                  );
  return Status;
}
