This directory will be used to contain the new EDK II files:
    FrameworkDatabase.db  - Second generation XML workspace info
    target.txt            - Restricts a build to defined values
    tools_def.txt         - Information about 3rd party tools

These files will be created from the template files in the new
BaseTools\Conf directory if and only if they do not exist.
