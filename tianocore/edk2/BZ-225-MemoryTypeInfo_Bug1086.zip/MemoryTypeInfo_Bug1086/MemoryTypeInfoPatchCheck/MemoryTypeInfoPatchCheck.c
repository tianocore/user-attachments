/** @file
  This application is to check whether the MemoryTypeInfo patch (MemoryTypeInfoVarCheckLib)
  has been applied correctly or not.

Copyright (c) 2018, Intel Corporation. All rights reserved.<BR>
This program and the accompanying materials
are licensed and made available under the terms and conditions of the BSD License
which accompanies this distribution.  The full text of the license may be found at
http://opensource.org/licenses/bsd-license.php

THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.

**/

#include <PiDxe.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/DebugLib.h>
#include <Library/PrintLib.h>
#include <Library/UefiLib.h>

#include <Guid/MemoryTypeInformation.h>

/**
  The Entry Point for Application.
  It is to check whether the MemoryTypeInfo patch (MemoryTypeInfoVarCheckLib)
  has been applied correctly or not.

  @param[in] ImageHandle    The firmware allocated handle for the EFI image.
  @param[in] SystemTable    A pointer to the EFI System Table.

  @retval EFI_SUCCESS       The entry point is executed successfully.

**/
EFI_STATUS
EFIAPI
MemoryTypeInfoPatchCheckEntrypoint (
  IN EFI_HANDLE           ImageHandle,
  IN EFI_SYSTEM_TABLE     *SystemTable
  )
{
  EFI_STATUS                    Status;
  EFI_MEMORY_TYPE_INFORMATION   *MemoryTypeInfo;
  UINTN                         MemoryTypeInfoSize;
  BOOLEAN                       Correct;
  UINT32                        Type;
  UINT32                        NumberOfPages;

  Correct = TRUE;

  Status = GetVariable2 (
             EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
             &gEfiMemoryTypeInformationGuid,
             (VOID *) &MemoryTypeInfo,
             &MemoryTypeInfoSize
             );
  if (EFI_ERROR(Status)) {
    Print (L"%s variable is not found\n", EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME);
    Print (L"Please check why it is not created during boot!!!\n");
    return EFI_SUCCESS;
  }

  //
  // Check DataSize.
  //
  Status = gRT->SetVariable (
                  EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
                  &gEfiMemoryTypeInformationGuid,
                  EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
                  MemoryTypeInfoSize - 1,
                  MemoryTypeInfo
                  );
  if (!EFI_ERROR (Status)) {
    Correct = FALSE;
    goto Done;
  }
  Status = gRT->SetVariable (
                  EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
                  &gEfiMemoryTypeInformationGuid,
                  EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
                  MemoryTypeInfoSize + 1,
                  MemoryTypeInfo
                  );
  if (!EFI_ERROR (Status)) {
    Correct = FALSE;
    goto Done;
  }

  //
  // Check last Entry's Type.
  //
  Type = MemoryTypeInfo[MemoryTypeInfoSize / sizeof (EFI_MEMORY_TYPE_INFORMATION) - 1].Type;
  MemoryTypeInfo[MemoryTypeInfoSize / sizeof (EFI_MEMORY_TYPE_INFORMATION) - 1].Type = EfiReservedMemoryType;
  Status = gRT->SetVariable (
                  EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
                  &gEfiMemoryTypeInformationGuid,
                  EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
                  MemoryTypeInfoSize,
                  MemoryTypeInfo
                  );
  MemoryTypeInfo[MemoryTypeInfoSize / sizeof (EFI_MEMORY_TYPE_INFORMATION) - 1].Type = Type;
  if (!EFI_ERROR (Status)) {
    Correct = FALSE;
    goto Done;
  }

  if (MemoryTypeInfoSize / sizeof (EFI_MEMORY_TYPE_INFORMATION) >= 2) {
    //
    // Check the Type.
    //
    Type = MemoryTypeInfo[0].Type;
    MemoryTypeInfo[0].Type = EfiMaxMemoryType + 1;
    Status = gRT->SetVariable (
                    EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
                    &gEfiMemoryTypeInformationGuid,
                    EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
                    MemoryTypeInfoSize,
                    MemoryTypeInfo
                    );
    MemoryTypeInfo[0].Type = Type;
    if (!EFI_ERROR (Status)) {
      Correct = FALSE;
      goto Done;
    }
    Type = MemoryTypeInfo[0].Type;
    MemoryTypeInfo[0].Type = EfiMaxMemoryType;
    Status = gRT->SetVariable (
                    EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
                    &gEfiMemoryTypeInformationGuid,
                    EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
                    MemoryTypeInfoSize,
                    MemoryTypeInfo
                    );
    MemoryTypeInfo[0].Type = Type;
    if (!EFI_ERROR (Status)) {
      Correct = FALSE;
      goto Done;
    }

    //
    // Check the NumberOfPages.
    //
    NumberOfPages = MemoryTypeInfo[0].NumberOfPages;
    MemoryTypeInfo[0].NumberOfPages = MAX_UINT32;
    Status = gRT->SetVariable (
                    EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
                    &gEfiMemoryTypeInformationGuid,
                    EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
                    MemoryTypeInfoSize,
                    MemoryTypeInfo
                    );
    MemoryTypeInfo[0].NumberOfPages = NumberOfPages;
    if (!EFI_ERROR (Status)) {
      Correct = FALSE;
      goto Done;
    }
  }

Done:
  if (Correct) {
    Print (L"MemoryTypeInfo patch has been applied correctly, well done!!!\n");
  } else {
    gRT->SetVariable (
           EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
           &gEfiMemoryTypeInformationGuid,
           EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
           MemoryTypeInfoSize,
           MemoryTypeInfo
           );
    Print (L"MemoryTypeInfo patch is not applied correctly or not applied, please check!!!\n");
  }

  FreePool (MemoryTypeInfo);

  return EFI_SUCCESS;
}
