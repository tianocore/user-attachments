============================================================================
                    WHICH PLATFORM NEEDS TO APPLY THE PATCH
============================================================================
The platform has platform PEIM and MRC to use MemoryTypeInformation variable
and build MemoryTypeInformation HOB following the MemoryTypeInformation usage
described in https://github.com/tianocore-docs/Docs/raw/master/White_Papers/A_Tour_Beyond_BIOS_Memory_Map_And_Practices_in_UEFI_BIOS_V2.pdf
Memory Map in S4 resume - Memory Type Information.

============================================================================
                    HOW TO APPLY THE PATCH
============================================================================
1. MemoryTypeInfoVarCheckLib (prevent MemoryTypeInformation variable to be corrupted by
   defining and checking maximum threshold) is the code platform needs to apply like below
   in platform dsc.

  MdeModulePkg/Universal/Variable/RuntimeDxe/VariableSmm.inf {
    <LibraryClasses>
      VarCheckLib|MdeModulePkg/Library/VarCheckLib/VarCheckLib.inf
      NULL|MdeModulePkg/Library/MemoryTypeInfoVarCheckLib/MemoryTypeInfoVarCheckLib.inf
      ...
  }


2. The maximum threshold macro values and mMemoryTypeInfoMaxThreshold defined in it
   need to be customized based on platform.

#define MAX_THRESHOLD_RESERVED_MEMORY_TYPE  0x3000 // 0x3000000
#define MAX_THRESHOLD_RUNTIME_SERVICES_CODE 0x100  // 0x100000
#define MAX_THRESHOLD_RUNTIME_SERVICES_DATA 0x500  // 0x500000
#define MAX_THRESHOLD_ACPI_RECLAIM_MEMORY   0x100  // 0x100000
#define MAX_THRESHOLD_ACPI_MEMORY_NVS       0x60   // 0x60000

EFI_MEMORY_TYPE_INFORMATION mMemoryTypeInfoMaxThreshold[] = {


3. The application at https://github.com/jyao1/EdkiiShellTool/tree/master/EdkiiShellToolPkg/MemoryTypeInfo
   can be used to help dump MemoryTypeInformation usage, it can be built and then 
   run in shell.

============================================================================
                    HOW TO VERIFY THE PATCH
============================================================================
MemoryTypeInfoPatchCheck is the application to help check whether 
MemoryTypeInfoVarCheckLib is applied correctly, it can be built and then 
run in shell. It will show below message on screen if MemoryTypeInfoVarCheckLib
is applied correctly.

MemoryTypeInfo patch has been applied correctly, well done!!!