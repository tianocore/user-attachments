/** @file
  Implementation functions and structures for MemoryTypeInformation VarCheck library.

Copyright (c) 2018, Intel Corporation. All rights reserved.<BR>
This program and the accompanying materials
are licensed and made available under the terms and conditions of the BSD License
which accompanies this distribution.  The full text of the license may be found at
http://opensource.org/licenses/bsd-license.php

THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.

**/

#include <Library/VarCheckLib.h>
#include <Library/BaseLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/DebugLib.h>

#include <Guid/MemoryTypeInformation.h>

//
// NOTE:
//   These macros could be replaced by PCDs.
//   Their values may need be customized based on platform.
//
#define MAX_THRESHOLD_RESERVED_MEMORY_TYPE  0x200 // 0x200000
#define MAX_THRESHOLD_RUNTIME_SERVICES_CODE 0x100 // 0x100000
#define MAX_THRESHOLD_RUNTIME_SERVICES_DATA 0x100 // 0x200000
#define MAX_THRESHOLD_ACPI_RECLAIM_MEMORY   0x80  // 0x80000
#define MAX_THRESHOLD_ACPI_MEMORY_NVS       0x100 // 0x100000

//
// NOTE:
//   This array's entry count and the entries's Type should be same
//   with the default MemoryTypeInformation defined in platform PEIM.
//
EFI_MEMORY_TYPE_INFORMATION mMemoryTypeInfoMaxThreshold[] = {
  {
    EfiReservedMemoryType,
    MAX_THRESHOLD_RESERVED_MEMORY_TYPE
  },
  {
    EfiRuntimeServicesCode,
    MAX_THRESHOLD_RUNTIME_SERVICES_CODE
  },
  {
    EfiRuntimeServicesData,
    MAX_THRESHOLD_RUNTIME_SERVICES_DATA
  },
  {
    EfiACPIReclaimMemory,
    MAX_THRESHOLD_ACPI_RECLAIM_MEMORY
  },
  {
    EfiACPIMemoryNVS,
    MAX_THRESHOLD_ACPI_MEMORY_NVS
  },
  {
    EfiMaxMemoryType,
    0
  }
};

VAR_CHECK_VARIABLE_PROPERTY mMemoryTypeInfoVariableProperty = {
  VAR_CHECK_VARIABLE_PROPERTY_REVISION,
  0,
  EFI_VARIABLE_NON_VOLATILE | EFI_VARIABLE_BOOTSERVICE_ACCESS,
  sizeof (EFI_MEMORY_TYPE_INFORMATION),
  sizeof (EFI_MEMORY_TYPE_INFORMATION) * (EfiMaxMemoryType + 1)
};

/**
  SetVariable check handler for MemoryTypeInformation variable.

  @param[in] VariableName       Name of Variable to set.
  @param[in] VendorGuid         Variable vendor GUID.
  @param[in] Attributes         Attribute value of the variable.
  @param[in] DataSize           Size of Data to set.
  @param[in] Data               Data pointer.

  @retval EFI_SUCCESS           The SetVariable check result was success.
  @retval EFI_INVALID_PARAMETER An invalid combination of attribute bits, name, GUID,
                                DataSize and Data value was supplied.

**/
EFI_STATUS
EFIAPI
MemoryTypeInfoVarCheckHandler (
  IN CHAR16     *VariableName,
  IN EFI_GUID   *VendorGuid,
  IN UINT32     Attributes,
  IN UINTN      DataSize,
  IN VOID       *Data
  )
{
  EFI_MEMORY_TYPE_INFORMATION   *MemoryTypeInfo;
  UINTN                         Count;
  UINTN                         Index;
  UINTN                         Index2;

  if ((StrCmp (VariableName, EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME) != 0) ||
      !CompareGuid (VendorGuid, &gEfiMemoryTypeInformationGuid)) {
    //
    // It is not MemoryTypeInformation variable.
    //
    return EFI_SUCCESS;
  }

  if ((((Attributes & EFI_VARIABLE_APPEND_WRITE) == 0) && (DataSize == 0)) ||
      (Attributes == 0)) {
    //
    // Do not check variable deletion.
    //
    return EFI_SUCCESS;
  }

  //
  // Check DataSize.
  //
  if (DataSize != sizeof (mMemoryTypeInfoMaxThreshold)) {
    DEBUG ((
      DEBUG_ERROR,
      "ERROR: %a() - DataSize = 0x%x Expected = 0x%x\n",
      __FUNCTION__,
      DataSize,
      sizeof (mMemoryTypeInfoMaxThreshold)
      ));
    return EFI_SECURITY_VIOLATION;
  }

  //
  // Get entry Count.
  //
  Count = DataSize / sizeof (EFI_MEMORY_TYPE_INFORMATION);

  MemoryTypeInfo = (EFI_MEMORY_TYPE_INFORMATION *) Data;

  //
  // Check last entry's Type.
  //
  if (MemoryTypeInfo[Count - 1].Type != EfiMaxMemoryType) {
    DEBUG ((
      DEBUG_ERROR,
      "ERROR: %a() - Last(0x%x) entry's Type(0x%x) != EfiMaxMemoryType\n",
      __FUNCTION__,
      Count - 1,
      MemoryTypeInfo[Count - 1].Type
      ));
    return EFI_SECURITY_VIOLATION;
  }

  if (Count >= 2) {
    for (Index = 0; Index < Count - 1; Index++) {
      //
      // Check the Type.
      //
      if (MemoryTypeInfo[Index].Type > EfiMaxMemoryType) {
        //
        // The Type is invalid.
        //
        DEBUG ((
          DEBUG_ERROR,
          "ERROR: %a() - 0x%x entry's Type(0x%x) is invalid\n",
          __FUNCTION__,
          Index,
          MemoryTypeInfo[Index].Type
          ));
        return EFI_SECURITY_VIOLATION;
      }
      for (Index2 = Index + 1; Index2 < Count; Index2++) {
        if (MemoryTypeInfo[Index].Type == MemoryTypeInfo[Index2].Type) {
          //
          // Two entries have same Type.
          //
          DEBUG ((
            DEBUG_ERROR,
            "ERROR: %a() - 0x%x entry and 0x%x entry have same Type(0x%x)\n",
            __FUNCTION__,
            Index,
            Index2,
            MemoryTypeInfo[Index].Type
            ));
          return EFI_SECURITY_VIOLATION;
        }
      }

      //
      // Check the NumberOfPages.
      //
      for (Index2 = 0; mMemoryTypeInfoMaxThreshold[Index2].Type != EfiMaxMemoryType; Index2++) {
        if (MemoryTypeInfo[Index].Type == mMemoryTypeInfoMaxThreshold[Index2].Type) {
          if (MemoryTypeInfo[Index].NumberOfPages > mMemoryTypeInfoMaxThreshold[Index2].NumberOfPages) {
            //
            // The NumberOfPages exceeds the maximum threshold.
            //
            DEBUG ((
              DEBUG_ERROR,
              "ERROR: %a() - 0x%x entry's NumberOfPages(0x%x) with Type(0x%x) exceeds the maximum threshold(0x%x)\n",
              __FUNCTION__,
              Index,
              MemoryTypeInfo[Index].NumberOfPages,
              MemoryTypeInfo[Index].Type,
              mMemoryTypeInfoMaxThreshold[Index2].NumberOfPages
              ));
            return EFI_SECURITY_VIOLATION;
          }
          break;
        }
      }
      if (mMemoryTypeInfoMaxThreshold[Index2].Type == EfiMaxMemoryType) {
        //
        // No maximum threshold defined for this entry's Type.
        //
        DEBUG ((
          DEBUG_ERROR,
          "ERROR: %a() - No maximum threshold defined for this(0x%x) entry's Type(0x%x)\n",
          __FUNCTION__,
          Index,
          MemoryTypeInfo[Index].Type
          ));
        return EFI_SECURITY_VIOLATION;
      }
    }
  }

  return EFI_SUCCESS;
}

/**
  Constructor function of MemoryTypeInfoVarCheckLib to set property and
  register SetVariable check handler for MemoryTypeInformation variable.

  @param[in] ImageHandle    The firmware allocated handle for the EFI image.
  @param[in] SystemTable    A pointer to the EFI System Table.

  @retval EFI_SUCCESS       The constructor executed correctly.

**/
EFI_STATUS
EFIAPI
MemoryTypeInfoVarCheckLibConstructor (
  IN EFI_HANDLE             ImageHandle,
  IN EFI_SYSTEM_TABLE       *SystemTable
  )
{
  EFI_STATUS    Status;

  Status = VarCheckLibVariablePropertySet (
             EFI_MEMORY_TYPE_INFORMATION_VARIABLE_NAME,
             &gEfiMemoryTypeInformationGuid,
             &mMemoryTypeInfoVariableProperty
             );
  ASSERT_EFI_ERROR (Status);
  Status = VarCheckLibRegisterSetVariableCheckHandler (
             MemoryTypeInfoVarCheckHandler
             );
  ASSERT_EFI_ERROR (Status);

  return Status;
}
