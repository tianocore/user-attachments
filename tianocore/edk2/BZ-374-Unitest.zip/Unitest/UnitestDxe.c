#include <PiDxe.h>

#include <Library/S3BootScriptLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/DebugLib.h>


#define  IO_ADDRESS            MAX_UINT64
#define  MEM_ADDRESS           MAX_UINT64
#define  PCI_CONFIG_ADDRESS    MAX_UINT64
#define  PCI_SEGMENT           0
#define  SMBUS_ADDRESS         0
#define  COUNT_NUM             (8 * EFI_PAGE_SIZE)

VOID     *mBuffer  = NULL;
BOOLEAN  mTestFail = FALSE;

/**
  Entrypoint of the uni-test.

  @param[in] ImageHandle    The firmware allocated handle for the EFI image.
  @param[in] SystemTable    A pointer to the EFI System Table.

  @retval EFI_SUCCESS       The entry point is executed successfully.
  @retval other             Some error occurs when executing this entry point.
**/
EFI_STATUS
EFIAPI
UnitestEntryPoint (
  IN EFI_HANDLE           ImageHandle,
  IN EFI_SYSTEM_TABLE     *SystemTable
  )
{
  EFI_STATUS    Status;
  UINTN         Length;

  DEBUG ((DEBUG_INFO, "Test start!\n"));

  if (mBuffer == NULL) {
    mBuffer = AllocatePages (EFI_SIZE_TO_PAGES (COUNT_NUM));
    ZeroMem (mBuffer, COUNT_NUM);
  }

  Status = S3BootScriptSaveIoWrite (
             S3BootScriptWidthUint8,
             IO_ADDRESS,
             COUNT_NUM,
             mBuffer
             );
  DEBUG ((DEBUG_INFO, "S3BootScriptSaveIoWrite() returns with %r.\n", Status));
  if (Status != EFI_OUT_OF_RESOURCES) {
    mTestFail = TRUE;
    goto Exit;
  }

  Status = S3BootScriptSaveMemWrite (
             S3BootScriptWidthUint8,
             MEM_ADDRESS,
             COUNT_NUM,
             mBuffer
             );
  DEBUG ((DEBUG_INFO, "S3BootScriptSaveMemWrite() returns with %r.\n", Status));
  if (Status != EFI_OUT_OF_RESOURCES) {
    mTestFail = TRUE;
    goto Exit;
  }

  Status = S3BootScriptSavePciCfgWrite (
             S3BootScriptWidthUint8,
             PCI_CONFIG_ADDRESS,
             COUNT_NUM,
             mBuffer
             );
  DEBUG ((DEBUG_INFO, "S3BootScriptSavePciCfgWrite() returns with %r.\n", Status));
  if (Status != EFI_OUT_OF_RESOURCES) {
    mTestFail = TRUE;
    goto Exit;
  }

  Status = S3BootScriptSavePciCfg2Write (
             S3BootScriptWidthUint8,
             PCI_SEGMENT,
             PCI_CONFIG_ADDRESS,
             COUNT_NUM,
             mBuffer
             );
  DEBUG ((DEBUG_INFO, "S3BootScriptSavePciCfg2Write() returns with %r.\n", Status));
  if (Status != EFI_OUT_OF_RESOURCES) {
    mTestFail = TRUE;
    goto Exit;
  }

  Length = COUNT_NUM;
  Status = S3BootScriptSaveSmbusExecute (
             SMBUS_ADDRESS,
             EfiSmbusQuickRead,
             &Length,
             mBuffer
             );
  DEBUG ((DEBUG_INFO, "S3BootScriptSaveSmbusExecute() returns with %r.\n", Status));
  if (Status != EFI_OUT_OF_RESOURCES) {
    mTestFail = TRUE;
    goto Exit;
  }

  Status = S3BootScriptSaveInformation (COUNT_NUM, mBuffer);
  DEBUG ((DEBUG_INFO, "S3BootScriptSaveInformation() returns with %r.\n", Status));
  if (Status != EFI_OUT_OF_RESOURCES) {
    mTestFail = TRUE;
    goto Exit;
  }

  //
  // Implementation of S3BootScriptSaveInformationAsciiString() calls
  // S3BootScriptSaveInformation(). So skip this API.
  //

  SetMem (mBuffer, COUNT_NUM - 1, ' ');
  Status = S3BootScriptLabel (TRUE, TRUE, NULL, (CHAR8 *)mBuffer);
  DEBUG ((DEBUG_INFO, "S3BootScriptLabel() returns with %r.\n", Status));
  if (Status != EFI_OUT_OF_RESOURCES) {
    mTestFail = TRUE;
    goto Exit;
  }

Exit:
  if (mTestFail) {
    DEBUG ((DEBUG_ERROR, "Test FAILED!\n"));
  } else {
    DEBUG ((DEBUG_INFO, "Test PASSED!\n"));
  }

  if (mBuffer != NULL) {
    FreePages (mBuffer, EFI_SIZE_TO_PAGES (COUNT_NUM));
    mBuffer = NULL;
  }

  return EFI_SUCCESS;
}
