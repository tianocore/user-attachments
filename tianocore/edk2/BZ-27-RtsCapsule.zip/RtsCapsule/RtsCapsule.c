#include <Uefi.h>
#include <Library/DebugLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/BaseLib.h>
#include <Library/UefiLib.h>
#include <Library/BaseMemoryLib.h>
//#include <Protocol/UsbIo.h>
#include <Protocol/FirmwareManagement.h>

//#include "Library/RtsCommonLib/devctrl.h"
//#include "Library/RtsCommonLib/RtsLog.h"
#include "RtsCapsule.h"

//#define gBS lBS
extern EFI_BOOT_SERVICES     *gBS;

EFI_FIRMWARE_MANAGEMENT_PROTOCOL gRtsCapsuleFmp ={
	RtsCapsule_GetImageInfo,
	RtsCapsule_GetImage,
	RtsCapsule_SetImage,
	RtsCapsule_CheckImage,
	RtsCapsule_GetPackageInfo,
	RtsCapsule_SetPackageInfo
};

EFI_STATUS
EFIAPI
RtsCapsule_GetImageInfo(
IN EFI_FIRMWARE_MANAGEMENT_PROTOCOL       *This,
IN OUT    UINTN                           *ImageInfoSize,
IN OUT    EFI_FIRMWARE_IMAGE_DESCRIPTOR   *ImageInfo,
OUT       UINT32                          *DescriptorVersion,
OUT       UINT8                           *DescriptorCount,
OUT       UINTN                           *DescriptorSize,
OUT       UINT32                          *PackageVersion,
OUT       CHAR16                          **PackageVersionName
)
{
	//RTS_ENTER();
	//RTS_RETURN(EFI_SUCCESS);
	return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
RtsCapsule_GetImage(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL  *This,
IN  UINT8                             ImageIndex,
IN  OUT  VOID                         *Image,
IN  OUT  UINTN                        *ImageSize
)
{
	//RTS_ENTER();
	//RTS_RETURN(EFI_SUCCESS);
	return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
RtsCapsule_SetImage(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL                 *This,
IN  UINT8                                            ImageIndex,
IN  CONST VOID                                       *Image,
IN  UINTN                                            ImageSize,
IN  CONST VOID                                       *VendorCode,
IN  EFI_FIRMWARE_MANAGEMENT_UPDATE_IMAGE_PROGRESS    Progress,
OUT CHAR16                                           **AbortReason
)
{
	//RTS_ENTER();
	//RTS_RETURN(EFI_SUCCESS);
	return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
RtsCapsule_CheckImage(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL  *This,
IN  UINT8                             ImageIndex,
IN  CONST VOID                        *Image,
IN  UINTN                             ImageSize,
OUT UINT32                            *ImageUpdatable
)
{
	//RTS_ENTER();
	//RTS_RETURN(EFI_SUCCESS);
	return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
RtsCapsule_GetPackageInfo(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL *This,
OUT UINT32                           *PackageVersion,
OUT CHAR16                           **PackageVersionName,
OUT UINT32                           *PackageVersionNameMaxLen,
OUT UINT64                           *AttributesSupported,
OUT UINT64                           *AttributesSetting
)
{
	//RTS_ENTER();
	//RTS_RETURN(EFI_SUCCESS);
	return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
RtsCapsule_SetPackageInfo(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL   *This,
IN  CONST VOID                         *Image,
IN  UINTN                              ImageSize,
IN  CONST VOID                         *VendorCode,
IN  UINT32                             PackageVersion,
IN  CONST CHAR16                       *PackageVersionName
)
{
	//RTS_ENTER();
	//RTS_RETURN(EFI_SUCCESS);
	return EFI_SUCCESS;
}

/**
Entrypoint of Realtek Capsule Driver.

This function is the entrypoint of Realtek USB Camera. It installs Driver Binding
Protocols together with Component Name Protocols.

@param  ImageHandle       The firmware allocated handle for the EFI image.
@param  SystemTable       A pointer to the EFI System Table.

@retval EFI_SUCCESS       The entry point is executed successfully.

**/
EFI_STATUS
	EFIAPI
	UefiMain(
	IN EFI_HANDLE           ImageHandle,
	IN EFI_SYSTEM_TABLE     *SystemTable
	)
{
	EFI_STATUS              Status;
	//RtsLogInit((UINT)RTS_LOG_DEBUG, 0, 0, 0, SystemTable->BootServices);
	//RTS_ENTER();

	Status = gBS->InstallProtocolInterface(&ImageHandle,
		&gEfiFirmwareManagementProtocolGuid,
		EFI_NATIVE_INTERFACE,
		&gRtsCapsuleFmp);

	//RTS_DEBUG(LOG_DEFAULT, L"Install status: 0x%X.\n", Status);
	ASSERT_EFI_ERROR(Status);
	//RtsLogDeInit();
	return EFI_SUCCESS;
}