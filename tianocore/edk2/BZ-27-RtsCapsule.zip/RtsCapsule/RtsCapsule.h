#ifndef __RTCAPSULE_H__
#define __RTCAPSULE_H__

EFI_STATUS
EFIAPI
RtsCapsule_GetImageInfo(
IN EFI_FIRMWARE_MANAGEMENT_PROTOCOL       *This,
IN OUT    UINTN                           *ImageInfoSize,
IN OUT    EFI_FIRMWARE_IMAGE_DESCRIPTOR   *ImageInfo,
OUT       UINT32                          *DescriptorVersion,
OUT       UINT8                           *DescriptorCount,
OUT       UINTN                           *DescriptorSize,
OUT       UINT32                          *PackageVersion,
OUT       CHAR16                          **PackageVersionName
);

EFI_STATUS
EFIAPI
RtsCapsule_GetImage(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL  *This,
IN  UINT8                             ImageIndex,
IN  OUT  VOID                         *Image,
IN  OUT  UINTN                        *ImageSize
);

EFI_STATUS
EFIAPI
RtsCapsule_SetImage(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL                 *This,
IN  UINT8                                            ImageIndex,
IN  CONST VOID                                       *Image,
IN  UINTN                                            ImageSize,
IN  CONST VOID                                       *VendorCode,
IN  EFI_FIRMWARE_MANAGEMENT_UPDATE_IMAGE_PROGRESS    Progress,
OUT CHAR16                                           **AbortReason
);

EFI_STATUS
EFIAPI
RtsCapsule_CheckImage(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL  *This,
IN  UINT8                             ImageIndex,
IN  CONST VOID                        *Image,
IN  UINTN                             ImageSize,
OUT UINT32                            *ImageUpdatable
);

EFI_STATUS
EFIAPI
RtsCapsule_GetPackageInfo(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL *This,
OUT UINT32                           *PackageVersion,
OUT CHAR16                           **PackageVersionName,
OUT UINT32                           *PackageVersionNameMaxLen,
OUT UINT64                           *AttributesSupported,
OUT UINT64                           *AttributesSetting
);

EFI_STATUS
EFIAPI
RtsCapsule_SetPackageInfo(
IN  EFI_FIRMWARE_MANAGEMENT_PROTOCOL   *This,
IN  CONST VOID                         *Image,
IN  UINTN                              ImageSize,
IN  CONST VOID                         *VendorCode,
IN  UINT32                             PackageVersion,
IN  CONST CHAR16                       *PackageVersionName
);

#endif