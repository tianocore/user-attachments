//***********************************************************************
//*                                                                     *
//*   Copyright (c) 1985-2020, American Megatrends International LLC.   *
//*                                                                     *
//*      All rights reserved. Subject to AMI licensing agreement.       *
//*                                                                     *
//***********************************************************************

/** @file HttpBootStatic.c   
Provides the Static Http Boot related functions .

Copyright (c) 2015 - 2018, Intel Corporation. All rights reserved.<BR>
(C) Copyright 2016 Hewlett Packard Enterprise Development LP<BR>
SPDX-License-Identifier: BSD-2-Clause-Patent

**/


#include "HttpBootDxe.h"
#include <Library/UefiBootManagerLib.h>


/**
  Get the IPv4 and IPv6 Address  from the Input Devicepath.


  @param[in]   FilePath         Pointer to the device path which contains a IPV4 and IPV6 device path node.

  @retval EFI_SUCCESS            The IPV4 Address  and IPv6 Address are successfully assigned to Private variable  
          EFI_INVALID_PARAMETER   If FilePath is Null
**/
EFI_STATUS
HttpBootParseIpAddress (
  IN     EFI_DEVICE_PATH_PROTOCOL     *FilePath,
  IN HTTP_BOOT_PRIVATE_DATA         *Private
  )
{
  EFI_DEVICE_PATH_PROTOCOL  *TempDevicePath;
  EFI_DEV_PATH                      *Node;

  if (FilePath == NULL) {
    return EFI_INVALID_PARAMETER;
  }
   
  ZeroMem (&Private->StationIp, sizeof (EFI_IP_ADDRESS));
  ZeroMem (&Private->SubnetMask,  sizeof (EFI_IP_ADDRESS));
  ZeroMem (&Private->GatewayIp, sizeof (EFI_IP_ADDRESS));
  //
  // Extract the IPV4 address from the FilePath
  //
  
  TempDevicePath = FilePath;
  while (!IsDevicePathEnd (TempDevicePath)) {
      
   if ((DevicePathType (TempDevicePath) == MESSAGING_DEVICE_PATH) &&
           (DevicePathSubType (TempDevicePath) == MSG_IPv4_DP)) {
      Node = ( EFI_DEV_PATH *)TempDevicePath;
      
      CopyMem (&Private->StationIp.v4, &Node->Ipv4.LocalIpAddress, sizeof (EFI_IPv4_ADDRESS));
      CopyMem (&Private->SubnetMask.v4, &Node->Ipv4.SubnetMask , sizeof (EFI_IPv4_ADDRESS));
      CopyMem (&Private->GatewayIp.v4, &Node->Ipv4.GatewayIpAddress, sizeof (EFI_IPv4_ADDRESS));
   }
   else if ((DevicePathType (TempDevicePath) == MESSAGING_DEVICE_PATH) &&
                (DevicePathSubType (TempDevicePath) == MSG_IPv6_DP)) {
         Node = (EFI_DEV_PATH *)TempDevicePath ;
 
         CopyMem (&Private ->StationIp.v6,&Node ->Ipv6.LocalIpAddress,sizeof (EFI_IPv6_ADDRESS));
         CopyMem (&Private ->GatewayIp.v6,&Node ->Ipv6.GatewayIpAddress,sizeof (EFI_IPv6_ADDRESS));
     }
   
    TempDevicePath = NextDevicePathNode (TempDevicePath);
  }

  return EFI_SUCCESS;
}

/**
  The notify function of create event when performing a manual config.

  @param[in]    Event        The event this notify function registered to.
  @param[in]    Context      Pointer to the context data registered to the event.

**/
VOID
EFIAPI
IfConfigManualAddressNotify (
  IN EFI_EVENT    Event,
  IN VOID         *Context
  )
{
    *((BOOLEAN *) Context) = TRUE;
}
/**
  Configure Static Ip Address using Ip4config2 Protocol

  @param[in]  Private             Pointer to HTTP boot driver private data.
**/
EFI_STATUS 
StaticHttpBoot (HTTP_BOOT_PRIVATE_DATA        *Private)
{
    EFI_EVENT                        MappedEvt;
    BOOLEAN                          IsAddressOk;
    EFI_IP4_CONFIG2_POLICY           Policy;
    EFI_IP4_CONFIG2_MANUAL_ADDRESS   ManualAddress;
    EFI_STATUS                       Status;
    UINTN                            DataSize ;
    EFI_IP4_CONFIG2_PROTOCOL         *IfCfg ;
    EFI_EVENT                        TimeOutEvt ; 
    //
    // Create events & timers for asynchronous settings.
    //
    CopyMem (&ManualAddress.Address , &Private->StationIp.v4, sizeof (EFI_IPv4_ADDRESS));
    CopyMem (&ManualAddress.SubnetMask , &Private ->SubnetMask.v4, sizeof (EFI_IPv4_ADDRESS));

    
    Status = gBS->CreateEvent (
                    EVT_TIMER,
                    TPL_CALLBACK,
                    NULL,
                    NULL,
                    &TimeOutEvt
                    );
    if (EFI_ERROR(Status))
        return Status;
    
    Status = gBS->CreateEvent (
                EVT_NOTIFY_SIGNAL,
                TPL_NOTIFY,
                IfConfigManualAddressNotify,
                &IsAddressOk,
                &MappedEvt
                );
    if (EFI_ERROR(Status))
        return Status;

    IfCfg  = Private->Ip4Config2;  
    Status = IfCfg->RegisterDataNotify (
                            IfCfg,
                            Ip4Config2DataTypeManualAddress,
                            MappedEvt
                            );
    if (EFI_ERROR(Status))
        return Status;
    Policy = Ip4Config2PolicyStatic;
    Status = IfCfg->SetData (
                            IfCfg,
                            Ip4Config2DataTypePolicy,
                            sizeof (EFI_IP4_CONFIG2_POLICY),
                            &Policy
                            );
							
if (EFI_ERROR(Status))
        return Status;
    DataSize = sizeof (EFI_IP4_CONFIG2_MANUAL_ADDRESS);
    
    Status = IfCfg->SetData (
                          IfCfg,
                          Ip4Config2DataTypeManualAddress,
                          DataSize,
                          &ManualAddress
                          );
    if (Status == EFI_NOT_READY) {
        gBS->SetTimer (TimeOutEvt, TimerRelative, 50000000);
        while (EFI_ERROR (gBS->CheckEvent (TimeOutEvt))) {
            if (IsAddressOk) {
                Status = EFI_SUCCESS;
                break;
      }
    }
    }

    Status = IfCfg->UnregisterDataNotify (
                 IfCfg,
                 Ip4Config2DataTypeManualAddress,
                 MappedEvt
                 );
    
    return Status;
}                    

/**
  The notify function of create event when performing a manual config.

  @param[in]    Event        The event this notify function registered to.
  @param[in]    Context      Pointer to the context data registered to the event.

**/
VOID
EFIAPI
IfConfig6ManualAddressNotify (
  IN EFI_EVENT    Event,
  IN VOID         *Context
  )
{
  *((BOOLEAN *) Context) = TRUE;
}
/**
  Configure Static Ipv6 Address using Ip6config Protocol

  @param[in]  Private             Pointer to HTTP boot driver private data.
**/

EFI_STATUS 
StaticHttpIPv6Boot (HTTP_BOOT_PRIVATE_DATA        *Private)
{
    EFI_STATUS                       Status;
    EFI_IP6_CONFIG_PROTOCOL          *IfCfg;
	EFI_IP6_CONFIG_MANUAL_ADDRESS    CfgManAddr;
	UINT32                           CurDadXmits;
	UINTN                            CurDadXmitsLen;
	EFI_IP6_CONFIG_POLICY            Policy;
	EFI_EVENT                        TimeOutEvt;
	EFI_EVENT                        MappedEvt;
	BOOLEAN                          IsAddressOk;
    
	 // Set static host ip6 address list.
	 //   This is a asynchronous process.
	 //
	CopyMem (&CfgManAddr.Address,&Private->StationIp.v6,sizeof(EFI_IPv6_ADDRESS));
	CfgManAddr.PrefixLength = IP6_PREFIX_LENGTH;
	CfgManAddr.IsAnycast = FALSE ;
	
	IsAddressOk = FALSE;
	IfCfg  = Private->Ip6Config;
	Status = gBS->CreateEvent (
	                 EVT_TIMER,
	                 TPL_CALLBACK,
	                 NULL,
	                 NULL,
	                 &TimeOutEvt
	                 );
	if (EFI_ERROR(Status))
	 	return Status;
     
    Status = gBS->CreateEvent (
                 EVT_NOTIFY_SIGNAL,
                 TPL_NOTIFY,
                 IfConfig6ManualAddressNotify,
                 &IsAddressOk,
                 &MappedEvt
                 );
    if (EFI_ERROR(Status))
    	return Status;

	Status = IfCfg->RegisterDataNotify (
	                     IfCfg,
	                     Ip6ConfigDataTypeManualAddress,
	                     MappedEvt
	                     );
	if (EFI_ERROR (Status)) {
		return Status;
	}
	
	Policy = Ip6ConfigPolicyManual;
	Status = IfCfg->SetData (
	                     IfCfg,
	                     Ip6ConfigDataTypePolicy,
	                     sizeof (EFI_IP6_CONFIG_POLICY),
	                     &Policy
	                     );
	if (EFI_ERROR (Status)) {
	 goto ON_EXIT;
	      }
         
	Status = IfCfg->SetData (
	                     IfCfg,
	                     Ip6ConfigDataTypeManualAddress,
	                     sizeof(EFI_IP6_CONFIG_MANUAL_ADDRESS),
	                     &CfgManAddr
	                     );
         

	if (Status == EFI_NOT_READY) {
	//
	// Get current dad transmits count.
	//
	CurDadXmitsLen = sizeof (EFI_IP6_CONFIG_DUP_ADDR_DETECT_TRANSMITS);
	Status = IfCfg->GetData (
	              IfCfg,
	              Ip6ConfigDataTypeDupAddrDetectTransmits,
	              &CurDadXmitsLen,
	              &CurDadXmits
	              );
	if (EFI_ERROR (Status)) {
	  goto ON_EXIT;
	}

	gBS->SetTimer (TimeOutEvt, TimerRelative, 50000000 + 10000000 * CurDadXmits);

	while (EFI_ERROR (gBS->CheckEvent (TimeOutEvt))) {
		if (IsAddressOk) {
		Status = EFI_SUCCESS;
		break;
		}
	}
	}

	Status = IfCfg->SetData (
	                        IfCfg,
	                        Ip6ConfigDataTypeGateway,
	                        sizeof(EFI_IPv6_ADDRESS),
	                        &Private->GatewayIp.v6
	                        );
	if (EFI_ERROR (Status)) {
		goto ON_EXIT;
	}

ON_EXIT:

	Status = IfCfg->UnregisterDataNotify (
	           IfCfg,
	            Ip6ConfigDataTypeManualAddress,
	            MappedEvt
	            );

	if (EFI_ERROR (Status)) {
		return Status;
	}
	return Status;
             
}
/*********
  Get the IPv4Address,subnetMask,GatewayIp using Http Uri given by user,
  IPV4(ClientAddress,protocol,static or Dhcp ,gatewayip,subnetMask)/Dns(DnsIP1,DnsIP2...,IPn)/Uri(_http://DomainName/xxx.efi)

  @param[in]  Uri                   The URI string of the boot file.
  @param[out] LocalIP       	    Ipv4 LocalP is updated statically based on Uri
  @param[out] SubnetMask            Ipv4 SubnetMask is updated statically based on Uri
  @param[out] GatewayIp             Ipv4  GatewayIp is updated statically based on Uri
  @Param[out] String                The Error Message.
  
  @retval EFI_SUCCESS               IP Address is translated from String.
  @retval EFI_INVALID_PARAMETER     Url is not supported http and https
          EFI_UNSUPPORTED           If IP Addrress and static Uri is invalid
********/
EFI_STATUS
VerifyIpv4Address (
        IN   CHAR16             *Buffer,
        OUT  EFI_IP_ADDRESS     *LocalIp,
        OUT  EFI_IP_ADDRESS     *SubnetMask,
        OUT  EFI_IP_ADDRESS     *GatewayIp,
        OUT  CHAR16             *String 
        )
{
    CHAR16                        *EndPointer;
    RETURN_STATUS                  Status;
    EFI_IPv4_ADDRESS               Dns;
    CHAR8                         AsciiUri[URI_STR_MAX_SIZE];
    
    if (StrnCmp (Buffer ,L"ipv4(",5)){
        StrCpyS (String ,URI_STR_MAX_SIZE, L"Invalid Uri Format!");
        return EFI_UNSUPPORTED;
    }
    Buffer +=StrLen(L"ipv4(");
    Status = StrToIpv4Address (Buffer, &EndPointer,&LocalIp->v4,NULL);
    if (RETURN_ERROR (Status)){
        StrCpyS (String ,URI_STR_MAX_SIZE,L"Invalid LocalIP address!");
        return EFI_UNSUPPORTED;
    }
    Buffer = EndPointer;
    if (StrnCmp(Buffer,L",tcp,static,",12 ) && StrnCmp(Buffer,L",tcp,dhcp,",10 )){
        StrCpyS (String ,URI_STR_MAX_SIZE, L"Invalid Uri Format!");
        return EFI_UNSUPPORTED;
    }
    if (StrnCmp(Buffer,L",tcp,dhcp,",10))
        Buffer +=StrLen(L",tcp,static,");
    else 
        Buffer +=StrLen(L",tcp,dhcp,");
    
    Status = StrToIpv4Address (Buffer,&EndPointer, &GatewayIp->v4,NULL);
    if (RETURN_ERROR(Status)) {
        StrCpyS (String ,URI_STR_MAX_SIZE,L"Invalid GatewayIP Address!");
        return EFI_UNSUPPORTED;
    }
    Buffer = EndPointer + 1;
    Status = StrToIpv4Address (Buffer,&EndPointer, &SubnetMask->v4,NULL);
    if (RETURN_ERROR(Status)) {
        StrCpyS (String ,URI_STR_MAX_SIZE,L"Invalid SubnetMask Address!");
        return EFI_UNSUPPORTED;
    }
    Buffer = EndPointer;
    if (StrnCmp(Buffer,L")/uri(",6) && StrnCmp(Buffer,L")/dns(",6)){
        StrCpyS (String ,URI_STR_MAX_SIZE, L"Invalid Uri Format!");
        return EFI_UNSUPPORTED;
    }
    if (!StrnCmp(Buffer,L")/dns(",6))
    {
        Buffer += StrLen(L")/dns(");
        do{
            Status  = StrToIpv4Address (Buffer,&EndPointer, &Dns,NULL);
            if (RETURN_ERROR(Status)) {
               StrCpyS (String ,URI_STR_MAX_SIZE,L"Invalid DnsServerIP Address!");
               return EFI_UNSUPPORTED;
             }
            Buffer = EndPointer +1;
        }while(*EndPointer == L',');   
    }
    if (!StrnCmp (Buffer,L"}/uri(",6)){
        Buffer +=StrLen(L")/uri(");
        UnicodeStrToAsciiStrS (Buffer, AsciiUri, URI_STR_MAX_SIZE);
        Status = HttpBootCheckUriScheme (AsciiUri);
        return Status;
    }
        
    return EFI_SUCCESS;
}

/******
  Get the IPv6Address,GatewayIp6Address using Http Uri given by user,
  IPV6(LocalIp6Address,Tcp,static or dhcp,gatewayip6Address)/Dns(IP1,IP2,...,IPn)/Uri(_http://DomainName/xxx.efi)

  @param[in]  Buffer                  URI string of the boot file.
  @param[out] LocalIp                 Ipv6 LocalIp Address is updated statically based on Uri
  @param[out] GatewayIp               Ipv6  GatewayIp is updated statically based on Uri
  @Param[out] String                  The Error Message.
  
  @retval EFI_SUCCESS                 IP Address is translated from String.
  @retval EFI_INVALID_PARAMETER    	  Url is not supported http and https
          EFI_UNSUPPORTED             If IP Address is Invalid and Static Uri is invalid
*******/
EFI_STATUS
VerifyIpv6Address (
      IN   CHAR16 			*Buffer,
      OUT  EFI_IP_ADDRESS 	*LocalIp,
      OUT  EFI_IP_ADDRESS 	*GatewayIp,
      OUT  CHAR16 			*String  
	  )
{
    
    CHAR16                        *EndPointer;
    RETURN_STATUS                  Status;
    EFI_IPv6_ADDRESS                 Dns;
    CHAR8                         AsciiUri[URI_STR_MAX_SIZE];
    
    if (StrnCmp (Buffer ,L"ipv6(",5)){
        StrCpyS (String ,URI_STR_MAX_SIZE, L"Invalid Uri Format!");
        return EFI_UNSUPPORTED;
    }
    Buffer += StrLen (L"ipv6(");
    Status = StrToIpv6Address (Buffer, &EndPointer,&LocalIp->v6,NULL);
    if (RETURN_ERROR (Status)){
      StrCpyS (String ,URI_STR_MAX_SIZE, L"Invalid LocalIP address!");
      return EFI_UNSUPPORTED;
    }
    Buffer = EndPointer;
    if (StrnCmp(Buffer,L",tcp,static,",12) && StrnCmp(Buffer,L",tcp,dhcp,",10)){
      StrCpyS (String ,URI_STR_MAX_SIZE, L"Invalid Uri Format!");
      return EFI_UNSUPPORTED;
    }
    if (StrnCmp(Buffer,L",tcp,dhcp,",10))
        Buffer +=StrLen(L",tcp,static,");
    else
        Buffer +=StrLen(L",tcp,dhcp,");
    
    Status = StrToIpv6Address (Buffer,&EndPointer, &GatewayIp->v6,NULL);
    if (RETURN_ERROR (Status) ) {
      StrCpyS (String ,URI_STR_MAX_SIZE, L"Invalid GatewayIP Address!");
      return EFI_UNSUPPORTED;
    }
    Buffer = EndPointer;
    if (StrnCmp(Buffer,L")/uri(",6) && StrnCmp(Buffer,L")/dns(",6)){
        StrCpyS (String ,URI_STR_MAX_SIZE, L"Invalid Uri Format!");
        return EFI_UNSUPPORTED;
    }
    if (!StrnCmp(Buffer,L")/dns(",6))
    {
        Buffer += StrLen(L")/dns(");
        do{
            Status  = StrToIpv6Address (Buffer,&EndPointer, &Dns,NULL);
            if (RETURN_ERROR(Status)) {
               StrCpyS (String ,URI_STR_MAX_SIZE,L"Invalid DnsServerIP Address!");
               return EFI_UNSUPPORTED;
             }
            Buffer = EndPointer +1;
        }while(*EndPointer == L',');   
    }
    if (!StrnCmp (Buffer,L"}/uri(",6)){
        Buffer +=StrLen(L")/uri(");
        UnicodeStrToAsciiStrS (Buffer, AsciiUri, URI_STR_MAX_SIZE);
        Status = HttpBootCheckUriScheme (AsciiUri);
        return Status;
    }
    return EFI_SUCCESS;
}
/******
This function checks static Uri given by user and returns BOOLEAN(TRUE:valid Uri,FALSE:Invalid Uri)

@param[in]  Buffer               The URI string of the boot file.

@retval SUCCESS   Uri and static IP address are valid. 
        EFI_UNSUPPORTED Static Uri is invalid Format.
		EFI_INVALID_PARAMETER  Url is not supported http and https
*******/
EFI_STATUS
HttpBootCheckStaticUri(IN CHAR16 *Uri)
{
    EFI_STATUS                      Status;
    EFI_INPUT_KEY                   Key;
    EFI_IP_ADDRESS                  LocalIp;
    EFI_IP_ADDRESS                  SubnetMask;
    EFI_IP_ADDRESS                  GatewayIp;
    CHAR16                          ErrorMessage[URI_STR_MAX_SIZE];
    UINTN                           Index = 0;
    
    if (StrLen (Uri) == 0)
        return EFI_INVALID_PARAMETER;
      
    for (Index = 0; Index < StrLen (Uri); Index++) {
        if (Uri[Index] == L'/' && Uri[Index + 1] == L'/') {
          break;
        }
      if (Uri[Index] >= L'A' && Uri[Index] <= L'Z') {
        Uri[Index] -= (CHAR16)(L'A' - L'a');
      }
    }
    if (StrnCmp (Uri,L"ipv4(",5) == 0){
        Status = VerifyIpv4Address (Uri,&LocalIp,&SubnetMask,&GatewayIp,ErrorMessage);
        if (EFI_ERROR(Status)){
           CreatePopUp (
               EFI_LIGHTGRAY | EFI_BACKGROUND_BLUE,
               &Key,
               ErrorMessage,
               NULL
               );
           return Status;
       }
    }else if (StrnCmp (Uri,L"ipv6(",5) == 0){
        Status = VerifyIpv6Address (Uri,&LocalIp,&GatewayIp,ErrorMessage);
        if (EFI_ERROR(Status)){
            CreatePopUp (
               EFI_LIGHTGRAY | EFI_BACKGROUND_BLUE,
               &Key,
               ErrorMessage,
               NULL
               );
            return Status;
        }
    }else  if ((StrnCmp(Uri, L"http://", 7) != 0) && (StrnCmp(Uri, L"https://", 8) != 0)){
        CreatePopUp (
               EFI_LIGHTGRAY | EFI_BACKGROUND_BLUE,
               &Key,
               L"Invalid Uri",
               NULL
               );
        return EFI_UNSUPPORTED;
    }
    return EFI_SUCCESS ;
}
/**
  Checks the HttpBoot Mode is static or Dhcp  from the Input Devicepath.
  And Update Private Variable Private->UsingStatic


  @param[in]   FilePath         Pointer to the device path which contains a IPV4 and IPv6 device path node.

  @retval EFI_SUCCESS            The IPV4 Address  and IPv6 Address are successfully assigned to Private variable  
          EFI_INVALID_PARAMETER   If FilePath is Null
**/
EFI_STATUS
HttpBootCheckBootType (IN     EFI_DEVICE_PATH_PROTOCOL     *FilePath,IN HTTP_BOOT_PRIVATE_DATA         *Private)
{
    EFI_DEVICE_PATH_PROTOCOL  *TempDevicePath;
    EFI_DEV_PATH                      *Node;

      if (FilePath == NULL) {
        return EFI_INVALID_PARAMETER;
      }
      
      TempDevicePath = FilePath;
      while (!IsDevicePathEnd (TempDevicePath)) {
        if ((DevicePathType (TempDevicePath) == MESSAGING_DEVICE_PATH)){
            if (DevicePathSubType (TempDevicePath) == MSG_IPv4_DP){ 
                Node = (EFI_DEV_PATH *)TempDevicePath ;
                Private->UsingStatic = Node->Ipv4.StaticIpAddress ;
            }else if (DevicePathSubType (TempDevicePath) == MSG_IPv6_DP){
                Node = (EFI_DEV_PATH *)TempDevicePath ;
                Private->UsingStatic =(Node->Ipv6.IpAddressOrigin == 0x03) ? TRUE : FALSE;
            }
        }
        TempDevicePath = NextDevicePathNode (TempDevicePath);
      }

      return EFI_SUCCESS;
}
/**
  Get the IPv4 and IPv6 Dns Address from Input Uri


  @param[in]   Uri               Input Uri from Filepath
  @param[in]   UsingIPv6         Specifies the type of IP addresses.
  @param[in]   Private           The pointer to the driver's private data.

  @retval EFI_SUCCESS            The IPV4 Address  and IPv6 Address are successfully assigned to HTTP boot driver private data. 
          EFI_INVALID_PARAMETER   If Uri is not a valid Static Devicepath URI
**/
EFI_STATUS
HttpBootParseDnsIp(IN CHAR8  *Uri,BOOLEAN  UsingIpv6,IN HTTP_BOOT_PRIVATE_DATA         *Private)
{
    EFI_STATUS           Status;
    CHAR16               Uri2[URI_STR_MAX_SIZE];
    UINT32               Index = 0;
    UINTN                UriStrLength = 0;
    CHAR16              *EndPointer;
    CHAR16              *Buffer;
    UINTN                DataSize = 0;
    
    if (Uri == NULL)
        return EFI_SUCCESS;
    AsciiStrToUnicodeStrS(Uri,Uri2,URI_STR_MAX_SIZE);
    UriStrLength = AsciiStrLen(Uri) + 1;
    Status = HttpBootCheckStaticUri(Uri2);
    if (EFI_ERROR(Status))
        return Status;
    if (Buffer = StrStr(Uri2,L"dns("))
    {
        Buffer += 4;
        DataSize = sizeof(EFI_IP_ADDRESS) ;
        Private->DnsServerIp = AllocateZeroPool(DataSize);
        if (UsingIpv6)
            Status = StrToIpv6Address (Buffer,&EndPointer,&Private->DnsServerIp[Index++].v6,NULL);
        else
            Status = StrToIpv4Address (Buffer,&EndPointer,&Private->DnsServerIp[Index++].v4,NULL);
        if (EFI_ERROR(Status)){
            FreePool(Private->DnsServerIp);
            Private->DnsServerIp = NULL;
            return Status;
        }
        while(*EndPointer == L','){
            Private->DnsServerIp = ReallocatePool(DataSize,DataSize + sizeof(EFI_IP_ADDRESS),Private->DnsServerIp);
            if (UsingIpv6)
                Status = StrToIpv6Address (Buffer,&EndPointer,&Private->DnsServerIp[Index++].v6,NULL);
            else
                Status = StrToIpv4Address (Buffer,&EndPointer,&Private->DnsServerIp[Index++].v4,NULL);
            if (EFI_ERROR(Status)){
                FreePool(Private->DnsServerIp);
                Private->DnsServerIp = NULL;
                return Status;
            }
            Buffer = EndPointer + 1;
        }while(*EndPointer == L',');
    Private->DnsServerCount = Index;
    if (Buffer = StrStr(Uri2,L"http")){
        for (Index =0;Buffer[Index] != L')' && Buffer[Index] != L'\0'  ;Index++);
        Buffer[Index] = L'\0';
    }
    UnicodeStrToAsciiStrS(Buffer,Uri,UriStrLength);
    }
    return EFI_SUCCESS;
}

