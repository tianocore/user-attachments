/** @file -- DemoWrapperDriver.h

Copyright (c) 2015, Microsoft Corporation. All rights reserved.

**/

#ifndef _DEMO_WRAPPER_DRIVER_
#define _DEMO_WRAPPER_DRIVER_

/**
  Attempt to locate the image blob
  from within the current FFS.

  @param[out]  Buffer   VOID** that will be returned pointing to the start of the
                        blob section. (NULL on error.)
  @param[out]  Size     Size of the returned section. (0 on error.)

  @retval     EFI_SUCCESS   Blob has been successfully returned.
  @retval     Others        Blob could not be found. Ignore return data.

**/
STATIC
EFI_STATUS
FindInternalImage (
  OUT VOID        **Buffer,
  OUT UINTN       *Size
  );


/**
  Take the blob address and size and try to load it as a UEFI
  image that can be "Start"ed later.

  @param[in]  ParentHandle    Passed as the ParentImageHandle to LoadImage().
  @param[in]  Buffer          Pointer to the buffer where the EFI image is located.
  @param[in]  Size            Size of Buffer in bytes.
  @param[out] LoadedHandle    The ImageHandle returned by LoadImage().

  @retval     Status = LoadImage()

**/
STATIC
EFI_STATUS
LoadInternalImage (
  IN  EFI_HANDLE    ParentHandle,
  IN  VOID          *Buffer,
  IN  UINTN         Size,
  OUT EFI_HANDLE    *LoadedHandle
  );


/**
  Callback that actually invokes the driver application at a time when
  everything else is ready.

  @param[in]  Event     Event whose notification function is being invoked
  @param[in]  Context   Pointer to the notification function's context

**/
STATIC
VOID
EFIAPI
InvokeInternalDriver (
  IN      EFI_EVENT                 Event,
  IN      VOID                      *Context
  );

#endif // _DEMO_WRAPPER_DRIVER_
