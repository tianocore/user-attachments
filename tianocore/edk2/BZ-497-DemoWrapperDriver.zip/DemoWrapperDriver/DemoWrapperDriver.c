/** @file -- DemoWrapperDriver.c
This module is responsible for provisioning and loading the Computrace
pre-boot module and making sure that all dependencies are met.

Copyright (c) 2015, Microsoft Corporation. All rights reserved.

**/

#include <Library/BaseLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/DebugLib.h>
#include <Library/DevicePathLib.h>
#include <Library/DxeServicesLib.h>
#include <Library/UefiBootServicesTableLib.h>
#include <Library/UefiRuntimeServicesTableLib.h>
#include <Library/MsManufacturingModeLib.h>           // Current runtime mode

#include <Protocol/FirmwareVolume2.h>

#include <Guid/EventGroup.h>

#include "DemoWrapperDriver.h"

EFI_HANDLE                        mInternalEfiImage;
EFI_EVENT                         mImageInvokeEvent;


/**
  The driver's entry point.

  @param[in] ImageHandle  The firmware allocated handle for the EFI image.
  @param[in] SystemTable  A pointer to the EFI System Table.

  @retval EFI_SUCCESS     The entry point executed successfully.
  @retval other           Some error occured when executing this entry point.

**/
EFI_STATUS
EFIAPI
UefiMain (
  IN    EFI_HANDLE                  ImageHandle,
  IN    EFI_SYSTEM_TABLE            *SystemTable
  )
{
  EFI_STATUS    Status = EFI_SUCCESS;
  UINT8         *SectionData;
  UINTN         SectionSize;

  DEBUG(( DEBUG_INFO, "DemoWrapperDriver::%a()\n", __FUNCTION__ ));

  // Suppress execution if in MfgMode.
  if (MsGetUefiRuntimeMode() == MANUFACTURING_MODE)
  {
    DEBUG(( DEBUG_WARN, "%a - Suppressing execution during MfgMode!!\n", __FUNCTION__ ));
    return EFI_UNSUPPORTED;
  }

  //
  // A couple of steps that do exactly what they say.
  // Find the image blob and load it as an actual UEFI image.
  Status = FindInternalImage( &SectionData, &SectionSize );
  if (!EFI_ERROR( Status ))
  {
    Status = LoadInternalImage( ImageHandle,
                                  SectionData,
                                  SectionSize,
                                  &mInternalEfiImage );
    if (EFI_ERROR( Status ))
    {
      DEBUG(( DEBUG_ERROR, "%a - LoadInternalImage() failed! %r\n", __FUNCTION__, Status ));
      ASSERT_EFI_ERROR( Status );
    }
  }

  //
  // Okay, so now we have the EFI image and it can be "Start"ed later.
  // Need to locate some more things and register the callback.
  //

  //
  // Finally, if everything else is good, register the callback and let's get this show on the road.
  if (!EFI_ERROR( Status ))
  {
    Status = gBS->CreateEventEx( EVT_NOTIFY_SIGNAL,
                                 TPL_CALLBACK,                 // Same TPL as EfiCreateEventReadyToBoot()
                                 InvokeInternalDriver,
                                 NULL,                         // Notify Context
                                 &gEfiEventPostReadyToBootGuid,
                                 &mImageInvokeEvent );
    DEBUG(( DEBUG_VERBOSE, "%a - CreateEventEx() = %r\n", __FUNCTION__, Status ));
    if (EFI_ERROR( Status ))
    {
      DEBUG(( DEBUG_ERROR, "%a - CreateEventEx() failed! %r\n", __FUNCTION__, Status ));
      ASSERT_EFI_ERROR( Status );   // If this fails, we won't load, and tampering may not be reported.
    }
  }

  return Status;
} // UefiMain()


/**
  Attempt to located the image blob
  from within the current FFS.

  @param[out]  Buffer   VOID** that will be returned pointing to the start of the
                        section. (NULL on error.)
  @param[out]  Size     Size of the returned section. (0 on error.)

  @retval     EFI_SUCCESS   Blob has been successfully returned.
  @retval     Others        Blob could not be found. Ignore return data.

**/
STATIC
EFI_STATUS
FindInternalImage (
  OUT VOID        **Buffer,
  OUT UINTN       *Size
  )
{
  EFI_STATUS    Status;

  DEBUG(( DEBUG_INFO, "DemoWrapperDriver::%a()\n", __FUNCTION__ ));

  //
  // Attempt to locate the image.
  Status = GetSectionFromFfs( EFI_SECTION_RAW,    // SectionType
                              0,                  // SectionInstance
                              Buffer,             // Buffer
                              Size );             // Size
  DEBUG(( DEBUG_VERBOSE, "%a - GetSectionFromFfs() = %r\n", __FUNCTION__, Status ));

  //
  // If an error occurred, return invalid data.
  if (EFI_ERROR( Status ))
  {
    *Buffer = NULL;
    *Size = 0;
  }

  return Status;
} // FindInternalImage()


/**
  Take the blob address and size and try to load it as a UEFI
  image that can be "Start"ed later.

  @param[in]  ParentHandle    Passed as the ParentImageHandle to LoadImage().
  @param[in]  Buffer          Pointer to the buffer where the EFI image is located.
  @param[in]  Size            Size of Buffer in bytes.
  @param[out] LoadedHandle    The ImageHandle returned by LoadImage().

  @retval     EFI_SUCCESS     Image loaded successfully.
  @retval     EFI_NOT_FOUND   Could not find the FwVol device path.
  @retval     Others          LoadImage() result.

**/
STATIC
EFI_STATUS
LoadInternalImage (
  IN  EFI_HANDLE    ParentHandle,
  IN  VOID          *Buffer,
  IN  UINTN         Size,
  OUT EFI_HANDLE    *LoadedHandle
  )
{
  EFI_STATUS                Status;
  EFI_DEVICE_PATH_PROTOCOL  *TestDevicePath;
  UINTN                     NumberOfHandles, Index;
  EFI_HANDLE                *HandleBuffer = NULL;
  EFI_DEVICE_PATH           *AgentDevicePath = NULL;

  DEBUG(( DEBUG_INFO, "DemoWrapperDriver::%a()\n", __FUNCTION__ ));

  //
  // Step 1: Build the DevicePath starting with the FvDevicePath...
  // Locate all handles with a FwVol protocol.
  Status = gBS->LocateHandleBuffer( ByProtocol,
                                    &gEfiFirmwareVolume2ProtocolGuid,
                                    NULL,
                                    &NumberOfHandles,
                                    &HandleBuffer );
  DEBUG(( DEBUG_VERBOSE, "%a - LocateHandleBuffer() = %r\n", __FUNCTION__, Status ));
  if (EFI_ERROR( Status )) Status = EFI_NOT_FOUND;
  // Attempt to find the MEDIA_DEVICE_PATH corresponding to the FV.
  if (!EFI_ERROR( Status ))
  {
    Status = EFI_NOT_FOUND; // Set a default status in case we fall through the loop...

    for (Index = 0; Index < NumberOfHandles; Index++)
    {
      TestDevicePath = DevicePathFromHandle( HandleBuffer[Index] );
      DEBUG(( DEBUG_VERBOSE, "%a - Looking at device path T%x:S%x on Handle %X...\n", __FUNCTION__,
              TestDevicePath->Type, TestDevicePath->SubType, HandleBuffer[Index] ));
      if (TestDevicePath->Type == MEDIA_DEVICE_PATH &&
          TestDevicePath->SubType == MEDIA_PIWG_FW_VOL_DP)
      {
        DEBUG(( DEBUG_VERBOSE, "%a - DevicePath found!\n", __FUNCTION__ ));
        AgentDevicePath = FileDevicePath( HandleBuffer[Index], L"EmbeddedDriverAgent" );
        if (AgentDevicePath) Status = EFI_SUCCESS;
      }
    }

    // Clean up after yourself.
    if (HandleBuffer) FreePool( HandleBuffer );
  }

  //
  // Finally: Attempt to load the image...
  if (!EFI_ERROR( Status ))
  {
    Status = gBS->LoadImage( FALSE,             // BootPolicy
                             ParentHandle,      // ParentImageHandle
                             AgentDevicePath,   // DevicePath
                             Buffer,            // SourceBuffer
                             Size,              // SourceSize
                             LoadedHandle );    // ImageHandle
    DEBUG(( DEBUG_VERBOSE, "%a - LoadImage() = %r\n", __FUNCTION__, Status ));
  }

  // Always put away your toys.
  // This should be safe because LoadImage() will duplicate the device path
  // if it's needed for future reference.
  if (AgentDevicePath) FreePool( AgentDevicePath );

  return Status;
} // LoadInternalImage()


/**
  Callback that actually invokes the application at a time when
  everything else is ready.

  @param[in]  Event     Event whose notification function is being invoked
  @param[in]  Context   Pointer to the notification function's context

**/
STATIC
VOID
EFIAPI
InvokeInternalDriver (
  IN      EFI_EVENT                 Event,
  IN      VOID                      *Context
  )
{
  EFI_STATUS        Status;
  UINTN             ExitDataSize;

  DEBUG(( DEBUG_INFO, "DemoWrapperDriver::%a()\n", __FUNCTION__ ));

  //
  // Here's the big one...
  // Invoke driver.
  Status = gBS->StartImage( mInternalEfiImage,
                            &ExitDataSize,
                            NULL );
  DEBUG(( DEBUG_VERBOSE, "%a - StartImage() = %r\n", __FUNCTION__, Status ));
  // We don't actually CARE what the Status is, because there's really nothing
  // we can do other than report it.
  if (EFI_ERROR( Status ))
  {
    DEBUG(( DEBUG_ERROR, "%a - StartImage() Failed! %r\n", __FUNCTION__, Status ));
    ASSERT_EFI_ERROR( Status );   // NOTE: Maybe not necessary to ASSERT?
  }

  //
  // Once we're done, for better or worse, close the event.
  // Always put away your toys...
  gBS->CloseEvent( mImageInvokeEvent );
} // InvokeInternalDriver()
