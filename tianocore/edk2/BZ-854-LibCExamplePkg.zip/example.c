#include <stdio.h>
#include <Library/UefiLib.h>
#include <Library/BaseCryptLib.h>
#include <Library/MemoryAllocationLib.h>

int
main (
  IN int Argc,
  IN char **Argv
  )
{
    VOID* ctx_256 = NULL;
    CONST CHAR8 name[8] = "Mateusz";
    UINT8 name_hash[32];
    Print(L"Hello standard print\n");
    printf("Hello world!\n");
    ctx_256 = AllocateZeroPool(Sha256GetContextSize());
    printf("Sha256Init:\n");
    Sha256Init(ctx_256);
    printf("Sha256Update:\n");
    Sha256Update(ctx_256, (const void*) name, 8);
    printf("Sha256Final:\n");
    Sha256Final(ctx_256, name_hash);

    printf("Mateusz hash: ");
    for (int i = 0; i < 32; i++)
    {
        printf("0x%02X ", name_hash[i]);
    }
    FreePool(ctx_256);
    return(0);

}